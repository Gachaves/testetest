using VendaLocacaoAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace VendaLocacaoAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllers();
            builder.Services.AddDbContext<VendaLocacaoContext>(options =>
     options.UseSqlServer(builder.Configuration.GetConnectionString("VendaLocacaoContext")));





            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();

            app.UseExceptionHandler("/error");
            app.Map("/error", (HttpContext httpContext) =>
            {
                return Results.Problem("Ocorreu um erro no servidor.");
            });
        }
    }
}