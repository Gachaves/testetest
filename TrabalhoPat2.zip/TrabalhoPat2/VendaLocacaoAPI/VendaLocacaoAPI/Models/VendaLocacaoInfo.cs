﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VendaLocacaoAPI.Models
{
    public class Aluguel
    {
        [Key]
        public int Id { get; set; }
        public int ReservaId { get; set; }
        public Reserva? Reserva { get; set; }
        public DateTime DataInicioReal { get; set; }
        public DateTime DataFimReal { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal ValorTotal { get; set; }

        // Propriedade de navegação para Pagamento
        public Pagamento? Pagamento { get; set; }
    }

    public class Cliente
    {
        [Key]
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? CPF { get; set; }
        public DateTime DataNascimento { get; set; }
        public string? Endereco { get; set; }
        public string? Telefone { get; set; }

        // Propriedade de navegação para Reservas
        public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();
    }

    public class Pagamento
    {
        [Key]
        public int Id { get; set; }
        public int AluguelId { get; set; }
        public Aluguel? Aluguel { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Valor { get; set; }
        public DateTime DataPagamento { get; set; }
        public string? MetodoPagamento { get; set; }
        public DateTime DataVencimento { get; set; }
    }

    public class Reserva
    {
        [Key]
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public Cliente? Cliente { get; set; }
        public int VeiculoId { get; set; }
        public Veiculo? Veiculo { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public string? Status { get; set; } // "Ativa", "Cancelada"

        [Column(TypeName = "decimal(18,2)")]
        public decimal ValorTotal { get; set; }
    }

    public class Veiculo
    {
        [Key]
        public int Id { get; set; }
        public string? Marca { get; set; }
        public string? Modelo { get; set; }
        public int Ano { get; set; }
        public string? Placa { get; set; }
        public bool Disponivel { get; set; }
        public string? Tipo { get; set; } // "Venda" ou "Aluguel"

        [Column(TypeName = "decimal(18,2)")]
        public decimal PrecoVenda { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal PrecoAluguelPorDia { get; set; }

        // Propriedade de navegação para as Reservas
        public ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();
    }
}
