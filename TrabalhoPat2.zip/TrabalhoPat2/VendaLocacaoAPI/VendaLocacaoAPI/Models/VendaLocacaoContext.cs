﻿using Microsoft.EntityFrameworkCore;
using VendaLocacaoAPI.Models;

namespace VendaLocacaoAPI.Models
{
    public class VendaLocacaoContext : DbContext
    {
        public VendaLocacaoContext(DbContextOptions<VendaLocacaoContext> options) : base(options) { }

        // DbSets para cada entidade
        public DbSet<Aluguel> Alugueis { get; set; } = null!;
        public DbSet<Cliente> Clientes { get; set; } = null!;
        public DbSet<Pagamento> Pagamentos { get; set; } = null!;
        public DbSet<Reserva> Reservas { get; set; } = null!;
        public DbSet<Veiculo> Veiculos { get; set; } = null!;
    }
}
