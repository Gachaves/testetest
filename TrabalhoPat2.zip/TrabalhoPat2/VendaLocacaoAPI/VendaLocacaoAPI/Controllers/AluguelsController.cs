﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VendaLocacaoAPI.Models;

namespace VendaLocacaoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AluguelsController : ControllerBase
    {
        private readonly VendaLocacaoContext _context;

        public AluguelsController(VendaLocacaoContext context)
        {
            _context = context;
        }

        // GET: api/Aluguels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Aluguel>>> GetAlugueis()
        {
            return await _context.Alugueis.ToListAsync();
        }

        // GET: api/Aluguels/5
        [HttpGet("{id}")]
        public async Task<ActionResult> GetAluguel(int id)
        {
            var aluguel = await _context.Alugueis
                .Include(a => a.Reserva)
                .ThenInclude(r => r.Cliente)
                .Include(a => a.Pagamento)
                .FirstOrDefaultAsync(a => a.Id == id);

            if (aluguel == null)
            {
                return NotFound(new { message = "Aluguel não encontrado." });
            }

            // Retornando apenas as partes importantes
            return Ok(new
            {
                Id = aluguel.Id,
                DataInicioReal = aluguel.DataInicioReal,
                DataFimReal = aluguel.DataFimReal,
                ValorTotal = aluguel.ValorTotal,
                Reserva = new
                {
                    aluguel.Reserva.DataInicio,
                    aluguel.Reserva.DataFim,
                    Cliente = new
                    {
                        aluguel.Reserva.Cliente.Nome,
                        aluguel.Reserva.Cliente.CPF
                    }
                },
                Pagamento = aluguel.Pagamento != null ? new
                {
                    aluguel.Pagamento.Valor,
                    aluguel.Pagamento.DataPagamento,
                    aluguel.Pagamento.MetodoPagamento
                } : null
            });
        }


        // POST: api/Aluguels
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Aluguel>> PostAluguel(Aluguel aluguel)
        {
            _context.Alugueis.Add(aluguel);
            await _context.SaveChangesAsync();

            //return CreatedAtAction("GetAluguel", new { id = aluguel.Id }, aluguel);
            return CreatedAtAction(nameof(GetAluguel), new { id = aluguel.Id }, aluguel);
        }

        // DELETE: api/Aluguels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAluguel(int id)
        {
            var aluguel = await _context.Alugueis.FindAsync(id);
            if (aluguel == null)
            {
                return NotFound();
            }

            _context.Alugueis.Remove(aluguel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AluguelExists(int id)
        {
            return _context.Alugueis.Any(e => e.Id == id);
        }
    }
}
